package com.altimetrik.ee.demo.entity;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "bus")
public class Bus
{
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "bus_number")
    private String busNumber;

    @Column(name = "operator_name")
    private String operatorName;

    @Column(name = "destination_city")
    private String destinationCity;

    @Column(name = "source_city")
    private String sourceCity;

    @Column(name = "duration_in_minutes")
    private String durationInMinutes;

    @OneToMany(targetEntity = BusSchedule.class, mappedBy = "id", orphanRemoval = false, fetch = FetchType.LAZY)
    private List<BusSchedule> busSchedules;


    public Long getId() {
        return id;
    }

    public String getBusNumber() {
        return busNumber;
    }

    public String getOperatorName() {
        return operatorName;
    }

    public String getDestinationCity() {
        return destinationCity;
    }

    public String getSourceCity() {
        return sourceCity;
    }

    public String getDurationInMinutes() {
        return durationInMinutes;
    }

    public void setBusNumber(String busNumber) {
        this.busNumber = busNumber;
    }

    public void setOperatorName(String operatorName) {
        this.operatorName = operatorName;
    }

    public void setDestinationCity(String destinationCity) {
        this.destinationCity = destinationCity;
    }

    public void setSourceCity(String sourceCity) {
        this.sourceCity = sourceCity;
    }

    public void setDurationInMinutes(String durationInMinutes) {
        this.durationInMinutes = durationInMinutes;
    }

}
