package com.altimetrik.ee.demo.util;

import com.altimetrik.ee.demo.bean.BusResults;

import java.util.Comparator;

public interface ComparatorInterface
{

    class SortByASCByOperatorNameComparator implements Comparator<BusResults>
    {

        @Override
        public int compare(BusResults b1, BusResults b2)
        {
            return b1.getOperatorName().compareTo(b2.getOperatorName());
        }
    }

    class SortByDESCByOperatorNameComparator implements Comparator<BusResults>
    {

        @Override
        public int compare(BusResults b1, BusResults b2)
        {
            return b2.getOperatorName().compareTo(b1.getOperatorName());
        }
    }

    public class SortByASCByDepartureTimeComparator implements Comparator<BusResults>
    {
        @Override
        public int compare(BusResults b1, BusResults b2)
        {
            return b1.getDepartureTime().compareTo(b2.getDepartureTime());
        }
    }

    public class SortByDESCByDepartureTimeComparator implements Comparator<BusResults>
    {
        @Override
        public int compare(BusResults b1, BusResults b2)
        {
            return b2.getDepartureTime().compareTo(b1.getDepartureTime());
        }
    }

    public class SortByASCByArrivalTimeComparator implements Comparator<BusResults>
    {
        @Override
        public int compare(BusResults b1, BusResults b2)
        {
            return b1.getArrivalTime().compareTo(b2.getArrivalTime());
        }
    }

    public class SortByDESCByArrivalTimeComparator implements Comparator<BusResults>
    {
        @Override
        public int compare(BusResults b1, BusResults b2)
        {
            return b2.getArrivalTime().compareTo(b1.getArrivalTime());
        }
    }

    public class SortByASCByDurationComparator implements Comparator<BusResults>
    {
        @Override
        public int compare(BusResults b1, BusResults b2)
        {
            return b1.getDuration().compareTo(b2.getDuration());
        }
    }

    public class SortByDESCByDurationComparator implements Comparator<BusResults>
    {
        @Override
        public int compare(BusResults b1, BusResults b2)
        {
            return b2.getDuration().compareTo(b1.getDuration());
        }
    }

    public class SortByASCByPriceComparator implements Comparator<BusResults>
    {
        @Override
        public int compare(BusResults b1, BusResults b2)
        {
            return b1.getPrice().compareTo(b2.getPrice());
        }
    }

}
