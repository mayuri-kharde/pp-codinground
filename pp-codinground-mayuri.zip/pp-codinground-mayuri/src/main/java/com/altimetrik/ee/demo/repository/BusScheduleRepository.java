package com.altimetrik.ee.demo.repository;

import com.altimetrik.ee.demo.bean.SearchResultsJoin;
import com.altimetrik.ee.demo.entity.BusSchedule;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface BusScheduleRepository extends JpaRepository<BusSchedule, Long> {

	@Query("SELECT new com.altimetrik.ee.demo.bean.SearchResults(b.busNumber,b.operatorName, bs.departureTime, bs.arrivalTime, bs.duration, bs.price) FROM BusSchedule bs, Bus b " +
			"WHERE b.sourceCity = (:source) and b.destinationCity = (:destination) and bs.dayOfWeek = (:travelDay) " +
			"and where CONCAT(b.busNumber,b.operatorName, bs.departureTime, bs.arrivalTime, bs.duration, bs.price) LIKE %(:searchValue)%")
	List<SearchResultsJoin> searchBusesDeparture(@Param("source") final String source, @Param("destination") final String destination, @Param("travelDay") final Integer travelDay, @Param("searchValue") final String searchValue);

	@Query("SELECT new com.altimetrik.ee.demo.bean.SearchResults(b.busNumber,b.operatorName, bs.departureTime, bs.arrivalTime, bs.duration, bs.price) FROM BusSchedule bs, Bus b " +
			"WHERE b.sourceCity = (:source) and b.destinationCity = (:destination) and bs.dayOfWeek = (:arrivalDay) " +
			"and where CONCAT(b.busNumber,b.operatorName, bs.departureTime, bs.arrivalTime, bs.duration, bs.price) LIKE %(:searchValue)%")
	List<SearchResultsJoin> searchBusesArrival(@Param("source") final String source, @Param("destination") final String destination, @Param("arrivalDay") final Integer arrivalDay, @Param("searchValue") final String searchValue);


}
