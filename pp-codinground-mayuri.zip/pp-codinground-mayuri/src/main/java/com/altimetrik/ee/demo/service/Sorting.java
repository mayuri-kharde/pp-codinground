package com.altimetrik.ee.demo.service;

import com.altimetrik.ee.demo.bean.BusResults;
import com.altimetrik.ee.demo.util.ComparatorInterface;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;

@Service
public class Sorting
{
    public static void sortingBasedOnColumn(String sortValue, String sortType, List<BusResults> busResults)
    {
        switch(sortValue)
        {
            case "operatorName":
                switch (sortType)
                {
                    case "ASC":
                        Collections.sort(busResults, new ComparatorInterface.SortByASCByOperatorNameComparator());
                        break;
                    case "DESC":
                        Collections.sort(busResults, new ComparatorInterface.SortByDESCByOperatorNameComparator());
                        break;
                }
                break;
            case "departureTime":
                switch (sortType)
                {
                    case "ASC":
                        Collections.sort(busResults, new ComparatorInterface.SortByASCByDepartureTimeComparator());
                        break;
                    case "DESC":
                        Collections.sort(busResults, new ComparatorInterface.SortByDESCByDepartureTimeComparator());
                        break;
                }
                break;
            case "arrivalTime":
                switch (sortType)
                {
                    case "ASC":
                        Collections.sort(busResults, new ComparatorInterface.SortByASCByArrivalTimeComparator());
                        break;
                    case "DESC":
                        Collections.sort(busResults, new ComparatorInterface.SortByDESCByArrivalTimeComparator());
                        break;
                }
                break;
            case "duration":
                switch (sortType)
                {
                    case "ASC":
                        Collections.sort(busResults, new ComparatorInterface.SortByASCByDurationComparator());
                        break;
                    case "DESC":
                        Collections.sort(busResults, new ComparatorInterface.SortByDESCByDurationComparator());
                        break;
                }
                break;
            default:
                Collections.sort(busResults, new ComparatorInterface.SortByASCByPriceComparator());
                break;
        }
    }
}
