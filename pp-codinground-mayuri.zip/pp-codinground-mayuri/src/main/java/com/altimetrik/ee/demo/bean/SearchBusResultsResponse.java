package com.altimetrik.ee.demo.bean;

import java.util.ArrayList;
import java.util.List;

public class SearchBusResultsResponse
{
    private Integer totalCount;

    private List<BusResults> busResults;

    public SearchBusResultsResponse()
    {
        busResults = new ArrayList<>();
    }

    public Integer getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(Integer totalCount) {
        this.totalCount = totalCount;
    }

    public List<BusResults> getBusResults() {
        return busResults;
    }

    public void setBusResults(List<BusResults> busResults) {
        this.busResults = busResults;
    }
}

