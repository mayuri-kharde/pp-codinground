package com.altimetrik.ee.demo.service.impl;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.UUID;

import com.altimetrik.ee.demo.bean.*;
import com.altimetrik.ee.demo.repository.BusScheduleRepository;
import com.altimetrik.ee.demo.service.Sorting;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.altimetrik.ee.demo.entity.ComponentDetailsEntity;
import com.altimetrik.ee.demo.repository.ComponentDetailsRepository;
import com.altimetrik.ee.demo.service.ComponentDetailsService;
import org.springframework.web.bind.annotation.RequestBody;

import javax.validation.Valid;


@Service
public class ComponentDetailsServiceImpl implements ComponentDetailsService {

	protected static Logger logger = LoggerFactory.getLogger(ComponentDetailsServiceImpl.class.getName());

	@Value("${spring.application.name}")
	private String applicationName;

	@Autowired
	private ComponentDetailsRepository componentDetailsRepository;

	@Autowired
	private BusScheduleRepository busScheduleRepository;

	@Override
	public PairedComponentDetailsBean findAll(final String applicationName) {
		final PairedComponentDetailsBean pairedComponentDetails = new PairedComponentDetailsBean(
				this.componentDetailsRepository.getByComponentName(applicationName),
				this.componentDetailsRepository.getByComponentNameNotIn(applicationName));
		return pairedComponentDetails;
	}

	@Override
	public SearchBusResultsResponse searchBuses(@Valid @RequestBody SearchBusRequest searchBusRequest)
	{
		String source = searchBusRequest.getSource();
		String destination = searchBusRequest.getDestination();
		String travelDate = searchBusRequest.getTravelDate();
		String returnDate = searchBusRequest.getReturnDate();
		String searchValue = searchBusRequest.getSearchValue();
		String sortValue = searchBusRequest.getSortColumn();
		String sortOrder = searchBusRequest.getSortOrder();

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d-MMM-yyyy");
		LocalDate travelLocalDate = LocalDate.parse(travelDate, formatter);
		Integer travelDay = travelLocalDate.getDayOfWeek().getValue();

		SearchBusResultsResponse searchBusResultsResponse = new SearchBusResultsResponse();
		List<BusResults> busResults = searchBusResultsResponse.getBusResults();

		List<SearchResultsJoin> departResults = busScheduleRepository.searchBusesDeparture(source, destination, travelDay, searchValue);

		for(SearchResultsJoin searchResultsJoin: departResults)
		{
			BusResults busResult = new BusResults();

			busResult.setBusNumber(searchResultsJoin.getBusNumber());
			busResult.setDuration(searchResultsJoin.getDuration());
			busResult.setPrice(searchResultsJoin.getPrice());
			busResult.setOperatorName(searchResultsJoin.getOperatorName());
			busResult.setArrivalTime(searchResultsJoin.getArrivalTime().toString());
			busResult.setDepartureTime(searchResultsJoin.getDepartureTime().toString());
			busResult.setTravelType("DEPART");

			busResults.add(busResult);
		}

		if(returnDate != null)
		{
			LocalDate returnLocalDate = LocalDate.parse(returnDate, formatter);
			Integer returnDay = returnLocalDate.getDayOfWeek().getValue();

			List<SearchResultsJoin> arrivalResults = busScheduleRepository.searchBusesArrival(destination, source, returnDay, searchValue);

			for(SearchResultsJoin searchResultsJoin: arrivalResults)
			{
				BusResults busResult = new BusResults();

				busResult.setBusNumber(searchResultsJoin.getBusNumber());
				busResult.setDuration(searchResultsJoin.getDuration());
				busResult.setPrice(searchResultsJoin.getPrice());
				busResult.setOperatorName(searchResultsJoin.getOperatorName());
				busResult.setArrivalTime(searchResultsJoin.getArrivalTime().toString());
				busResult.setDepartureTime(searchResultsJoin.getDepartureTime().toString());
				busResult.setTravelType("RETURN");

				busResults.add(busResult);
			}
		}

		Sorting.sortingBasedOnColumn(sortValue, sortOrder, busResults);
		searchBusResultsResponse.setBusResults(busResults);
		searchBusResultsResponse.setTotalCount(busResults.size());
		return searchBusResultsResponse;
	}

	@Override
	public boolean createComponentDetails(final String applicationName) {
		if (this.componentDetailsRepository.findByComponentName(applicationName) == null) {
			this.componentDetailsRepository
					.save(new ComponentDetailsEntity(applicationName, UUID.randomUUID().toString()));
		}
		return true;
	}

	@Scheduled(cron = "${cron.component.identifier.reg-ex}")
	public void regenerateComponentIdentifier() {
		final ComponentDetailsEntity componentDetails = this.componentDetailsRepository
				.findByComponentName(this.applicationName);
		componentDetails.setComponentIdentifier(UUID.randomUUID().toString());
		this.componentDetailsRepository.save(componentDetails);
	}

}
