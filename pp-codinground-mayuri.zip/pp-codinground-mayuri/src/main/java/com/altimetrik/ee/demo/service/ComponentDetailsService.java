package com.altimetrik.ee.demo.service;

import com.altimetrik.ee.demo.bean.SearchBusRequest;
import com.altimetrik.ee.demo.bean.SearchBusResultsResponse;
import org.springframework.stereotype.Service;

import com.altimetrik.ee.demo.bean.PairedComponentDetailsBean;

@Service
public interface ComponentDetailsService {

	boolean createComponentDetails(final String applicationName);

	PairedComponentDetailsBean findAll(final String applicationName);

    SearchBusResultsResponse searchBuses(SearchBusRequest searchBusBean);
}
