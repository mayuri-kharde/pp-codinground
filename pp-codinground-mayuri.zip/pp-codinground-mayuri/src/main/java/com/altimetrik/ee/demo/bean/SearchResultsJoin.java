package com.altimetrik.ee.demo.bean;

import java.time.LocalTime;

public class SearchResultsJoin
{
    private String busNumber;

    private String operatorName;

    private LocalTime departureTime;

    private LocalTime arrivalTime;

    private Integer duration;

    private Float price;

    public String getBusNumber() {
        return busNumber;
    }

    public String getOperatorName() {
        return operatorName;
    }

    public LocalTime getDepartureTime() {
        return departureTime;
    }

    public LocalTime getArrivalTime() {
        return arrivalTime;
    }

    public Integer getDuration() {
        return duration;
    }

    public Float getPrice() {
        return price;
    }

    public void setBusNumber(String busNumber) {
        this.busNumber = busNumber;
    }

    public void setOperatorName(String operatorName) {
        this.operatorName = operatorName;
    }

    public void setDepartureTime(LocalTime departureTime) {
        this.departureTime = departureTime;
    }

    public void setArrivalTime(LocalTime arrivalTime) {
        this.arrivalTime = arrivalTime;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    public void setPrice(Float price) {
        this.price = price;
    }

}
