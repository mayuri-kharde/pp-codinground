package com.altimetrik.ee.demo.bean;

import javax.validation.constraints.NotBlank;

public class SearchBusRequest
{
    @NotBlank(message = "Source city is mandatory")
    private String source;

    @NotBlank(message = "Destination city is mandatory")
    private String destination;

    @NotBlank(message = "Travel date is mandatory")
    private String travelDate;

    private String returnDate;

    private String searchValue;

    private String sortColumn;

    private String sortOrder;

    public String getSource()
    {
        return source;
    }

    public String getDestination()
    {
        return destination;
    }

    public String getTravelDate()
    {
        return travelDate;
    }

    public String getReturnDate()
    {
        return returnDate;
    }

    public String getSearchValue()
    {
        return searchValue;
    }

    public String getSortColumn()
    {
        return sortColumn;
    }

    public String getSortOrder()
    {
        return sortOrder;
    }
}
