package com.altimetrik.ee.demo.controller;

import com.altimetrik.ee.demo.bean.SearchBusBean;
import com.altimetrik.ee.demo.bean.SearchBusResultsBean;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.altimetrik.ee.demo.bean.PairedComponentDetailsBean;
import com.altimetrik.ee.demo.service.ComponentDetailsService;

import io.swagger.annotations.ApiOperation;

import java.util.List;

@RestController
@RequestMapping(value = "/service")
public class ServiceController {

	protected static Logger logger = LoggerFactory.getLogger(ServiceController.class.getName());

	@Value("${spring.application.name}")
	private String applicationName;

	@Autowired
	private ComponentDetailsService componentDetailsService;

	@GetMapping(value = "/")
	@ApiOperation(value = "Get service name and identifier", notes = "Get service details and its corresponding values for all paired services", response = PairedComponentDetailsBean.class)
	public PairedComponentDetailsBean findAll() {
		return componentDetailsService.findAll(this.applicationName);
	}

	@PostMapping(value = "/searchBuses")
	@ApiResponses({@ApiResponse(code = 403, message = "Unauthorized Access"), @ApiResponse(code = 404, message = "API Not Found")})
	public SearchBusResultsBean searchBuses(@RequestBody SearchBusBean searchBusBean)
	{
		return componentDetailsService.searchBuses(searchBusBean);
	}



}
