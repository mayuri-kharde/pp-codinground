# java8_springboot-2.0.5-api-template-3.0

Spring Boot with MySQL

For instructions, Please refer to the link `https://pg-gitlab.altimetrik.com/PlaygroundEngineeringEnv/java8_springboot-2.0.5-api-template-3.0/blob/master/EclipseCheUserGuide.pdf`

To connect to database console of the app available over `app access url`, Please refer to `/src/main/resources/db-config-k8s.properties` having the `url` and `JDBC connection properties`
 